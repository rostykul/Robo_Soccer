aclocal
automake --add-missing --include-deps
autoconf
./configure
make

